JWT_SECRET = "your_generated_jwt_secret"
ADMIN_API_KEY = "your_generated_admin_key"

OPENAI_API_KEY = "your_openai_key"
GEMINI_API_KEY = "your_gemini_key"
