import React from 'react';
import ChatBox from '../components/ChatBox';
import ToolCard from '../components/ToolCard';

export default function Dashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Cyber AI Dashboard</h1>
      <ChatBox />
      <div className="grid grid-cols-2 gap-4 mt-6">
        <ToolCard name="WHOIS Lookup" />
        <ToolCard name="Port Scanner" />
      </div>
    </div>
  );
}
