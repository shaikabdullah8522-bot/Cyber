import React, { useState } from 'react';

export default function ChatBox() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);

  const sendMessage = () => {
    setMessages([...messages, { from: 'user', text: input }]);
    setInput('');
  };

  return (
    <div className="border p-4 rounded">
      <h2 className="font-bold">AI Chat</h2>
      <div className="h-40 overflow-y-auto mb-2">
        {messages.map((m, i) => (
          <div key={i}><b>{m.from}:</b> {m.text}</div>
        ))}
      </div>
      <input value={input} onChange={e => setInput(e.target.value)} className="border p-1" />
      <button onClick={sendMessage} className="ml-2 bg-blue-500 text-white px-2">Send</button>
    </div>
  );
}
