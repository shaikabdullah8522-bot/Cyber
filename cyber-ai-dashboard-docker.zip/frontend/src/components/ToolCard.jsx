import React from 'react';

export default function ToolCard({ name }) {
  return (
    <div className="border p-4 rounded shadow">
      <h3 className="font-bold">{name}</h3>
      <button className="mt-2 bg-green-500 text-white px-2 py-1 rounded">Run</button>
    </div>
  );
}
